﻿$ErrorActionPreference = 'Stop'
$appName = 'المساعد القضائي الإلكتروني'
$dest = Join-Path $env:LOCALAPPDATA 'JudicialAgendaApp'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
$rtl = [System.Windows.Forms.MessageBoxOptions]'RtlReading,RightAlign'
function Say($msg, $icon) {
  [void][System.Windows.Forms.MessageBox]::Show($msg, $appName, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::$icon, [System.Windows.Forms.MessageBoxDefaultButton]::Button1, $rtl)
}
try {
  if (-not (Test-Path (Join-Path $dest 'JudicialAgenda.exe'))) { throw 'البرنامج غير مثبت على هذا الكمبيوتر.' }
  $stage = Join-Path $env:TEMP 'ja_offline_stage'
  if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
  New-Item -ItemType Directory -Path $stage | Out-Null
  Copy-Item $dest (Join-Path $stage 'JudicialAgendaApp') -Recurse
  $setup = Join-Path $dest 'setup'
  foreach ($f in @('Install.bat','install.ps1','Uninstall.bat','uninstall.ps1','make-offline-package.ps1','README.txt')) {
    $p = Join-Path $setup $f
    if (Test-Path $p) { Copy-Item $p $stage -Force }
  }
  $desk = [Environment]::GetFolderPath('Desktop')
  $out = Join-Path $desk 'Assistant-Offline-Package.zip'
  if (Test-Path $out) { Remove-Item $out -Force }
  [System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $out, [System.IO.Compression.CompressionLevel]::Fastest, $false)
  Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  Start-Process explorer.exe ('/select,"' + $out + '"')
  Say ('تم إنشاء حزمة التثبيت الأوفلاين على سطح المكتب:' + "`n" + 'Assistant-Offline-Package.zip' + "`n`n" + 'انقلها بفلاشة إلى أي كمبيوتر، وفك ضغطها، ثم شغّل Install.bat — بدون إنترنت وبدون أي برامج إضافية.' + "`n`n" + 'ملاحظة: الحزمة لا تحتوي على بياناتك (قضاياك)، لنقلها استخدم النسخة الاحتياطية أو المزامنة.') 'Information'
} catch {
  Say ('تعذر إنشاء الحزمة: ' + $_.Exception.Message) 'Error'
}
