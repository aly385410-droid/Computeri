﻿$ErrorActionPreference = 'Stop'
$ver  = '33.2.1'
$sha  = 'c325a6d905c67107e166267813ea2151ae7fd316c0a88de0081db0b9851a9946'
$appName = 'المساعد القضائي الإلكتروني'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'JudicialAgendaApp'
$lite = Join-Path $env:LOCALAPPDATA 'JudicialAssistantLite'
$liteData = Join-Path $env:LOCALAPPDATA 'JudicialAssistantData'
$exe  = Join-Path $dest 'JudicialAgenda.exe'
$tmpZip = Join-Path $env:TEMP ("electron-$ver.zip")
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$rtl = [System.Windows.Forms.MessageBoxOptions]'RtlReading,RightAlign'

function Say($msg, $icon) {
  [void][System.Windows.Forms.MessageBox]::Show($msg, $appName, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::$icon, [System.Windows.Forms.MessageBoxDefaultButton]::Button1, $rtl)
}
function Ask($msg) {
  return [System.Windows.Forms.MessageBox]::Show($msg, $appName, [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question, [System.Windows.Forms.MessageBoxDefaultButton]::Button2, $rtl)
}
function Test-Net {
  try {
    $r = [System.Net.WebRequest]::Create('https://github.com')
    $r.Timeout = 5000
    $r.Method = 'HEAD'
    $resp = $r.GetResponse()
    $resp.Close()
    return $true
  } catch {
    if ($_.Exception.Response) { return $true }
    return $false
  }
}
function Find-Browser {
  $bases = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) | Where-Object { $_ }
  $subs = @('Microsoft\Edge\Application\msedge.exe', 'Google\Chrome\Application\chrome.exe')
  foreach ($s in $subs) {
    foreach ($b in $bases) {
      $p = Join-Path $b $s
      if (Test-Path $p) { return $p }
    }
  }
  return $null
}
function Stop-App {
  Get-Process -Name 'JudicialAgenda' -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Milliseconds 800
}
function Expand-Runtime($zipPath) {
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $dest -Force
  Rename-Item (Join-Path $dest 'electron.exe') 'JudicialAgenda.exe'
  Remove-Item (Join-Path $dest 'resources\default_app.asar') -ErrorAction SilentlyContinue
}
function New-Lnk($path, $target, $arguments, $workDir, $icon, $desc) {
  $ws = New-Object -ComObject WScript.Shell
  $l = $ws.CreateShortcut($path)
  $l.TargetPath = $target
  if ($arguments) { $l.Arguments = $arguments }
  if ($workDir) { $l.WorkingDirectory = $workDir }
  if ($icon) { $l.IconLocation = $icon }
  $l.Description = $desc
  $l.Save()
}
function Copy-SetupFiles($setupDst) {
  if (-not (Test-Path $setupDst)) { New-Item -ItemType Directory -Path $setupDst | Out-Null }
  foreach ($f in @('Install.bat','install.ps1','Uninstall.bat','uninstall.ps1','make-offline-package.ps1','Get-OCR-Engine.ps1','Get-OCR-Engine.bat','README.txt')) {
    $p = Join-Path $here $f
    if (Test-Path $p) { Copy-Item $p $setupDst -Force }
  }
}
function Register-Shortcuts($target, $arguments, $workDir, $icon, $setupDst) {
  $desk = [Environment]::GetFolderPath('Desktop')
  $prog = [Environment]::GetFolderPath('Programs')
  $olds = @('الأجندة القضائية.lnk', 'السكرتير الإلكتروني.lnk', 'إلغاء تثبيت السكرتير الإلكتروني.lnk', 'السكرتير الإلكتروني - إنشاء حزمة تثبيت أوفلاين.lnk')
  foreach ($folder in @($desk, $prog)) {
    foreach ($o in $olds) {
      $op = Join-Path $folder $o
      if (Test-Path $op) { Remove-Item $op -Force -ErrorAction SilentlyContinue }
    }
    New-Lnk (Join-Path $folder ($appName + '.lnk')) $target $arguments $workDir $icon $appName
  }
  $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $un = Join-Path $setupDst 'uninstall.ps1'
  $unArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $un + '"'
  New-Lnk (Join-Path $prog ('إلغاء تثبيت ' + $appName + '.lnk')) $psExe $unArgs $null $icon ('إلغاء تثبيت ' + $appName)
  return @($psExe, $unArgs)
}
function Register-Uninstaller($installDir, $icon, $ver2, $psExe, $unArgs) {
  $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\JudicialAgenda'
  New-Item -Path $key -Force | Out-Null
  Set-ItemProperty -Path $key -Name 'DisplayName' -Value $appName
  Set-ItemProperty -Path $key -Name 'DisplayVersion' -Value $ver2
  Set-ItemProperty -Path $key -Name 'Publisher' -Value 'المستشار / محمد موسى والمستشار / محمد الغول'
  Set-ItemProperty -Path $key -Name 'InstallLocation' -Value $installDir
  Set-ItemProperty -Path $key -Name 'DisplayIcon' -Value $icon
  Set-ItemProperty -Path $key -Name 'UninstallString' -Value ('"' + $psExe + '" ' + $unArgs)
  New-ItemProperty -Path $key -Name 'NoModify' -Value 1 -PropertyType DWord -Force | Out-Null
  New-ItemProperty -Path $key -Name 'NoRepair' -Value 1 -PropertyType DWord -Force | Out-Null
}
function Read-Version($appDir) {
  try { return (Get-Content (Join-Path $appDir 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch { return '' }
}

function Choose-Mode($hasRuntime) {
  $f = New-Object System.Windows.Forms.Form
  $f.Text = $appName + ' - اختيار طريقة التثبيت'
  $f.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
  $f.RightToLeftLayout = $true
  $f.StartPosition = 'CenterScreen'
  $f.FormBorderStyle = 'FixedDialog'
  $f.MaximizeBox = $false
  $f.MinimizeBox = $false
  $f.ControlBox = $false
  $f.TopMost = $true
  $f.ClientSize = New-Object System.Drawing.Size(660, 520)
  $f.Font = New-Object System.Drawing.Font('Segoe UI', 10)
  $h = New-Object System.Windows.Forms.Label
  $h.Text = 'اختر طريقة تثبيت ' + $appName
  $h.Font = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
  $h.SetBounds(20, 15, 620, 34)
  $f.Controls.Add($h)
  $n = New-Object System.Windows.Forms.Label
  $n.Text = 'هذه خطوة أساسية في التثبيت ولا يمكن المتابعة بدونها.'
  $n.SetBounds(20, 52, 620, 26)
  $f.Controls.Add($n)
  $b1 = New-Object System.Windows.Forms.Button
  $b1.Text = '1) تثبيت بالإنترنت - النسخة الكاملة (مع المزامنة بين الهاتف والكمبيوتر)'
  $b1.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
  $b1.SetBounds(20, 90, 620, 52)
  $b1.DialogResult = [System.Windows.Forms.DialogResult]::Yes
  $f.Controls.Add($b1)
  $d1 = New-Object System.Windows.Forms.Label
  $d1.Text = 'يُنزَّل محرك البرنامج مرة واحدة (حوالي 110 ميجابايت) ثم يعمل بعدها بدون إنترنت. تستفيد من مزامنة بياناتك بين الهاتف والكمبيوتر عبر الشبكة المحلية.'
  if ($hasRuntime) { $d1.Text = 'تم العثور على المحرك ضمن ملفات التثبيت، فلن يلزم الإنترنت. تستفيد من مزامنة بياناتك بين الهاتف والكمبيوتر عبر الشبكة المحلية.' }
  $d1.SetBounds(30, 146, 600, 62)
  $f.Controls.Add($d1)
  $b2 = New-Object System.Windows.Forms.Button
  $b2.Text = '2) تثبيت بدون إنترنت - النسخة السريعة (بدون مزامنة)'
  $b2.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
  $b2.SetBounds(20, 222, 620, 52)
  $b2.DialogResult = [System.Windows.Forms.DialogResult]::No
  $f.Controls.Add($b2)
  $d2 = New-Object System.Windows.Forms.Label
  $d2.Text = 'لا يحتاج إنترنت ولا أي برنامج خارجي (يعمل عبر Microsoft Edge الموجود في Windows). تعمل كل مزايا البرنامج، لكن لا تتوفر المزامنة بين الهاتف والكمبيوتر.'
  $d2.SetBounds(30, 278, 600, 62)
  $f.Controls.Add($d2)
  $w = New-Object System.Windows.Forms.Label
  $w.Text = 'ملاحظة: النسختان لا تتشاركان البيانات. للانتقال من إحداهما للأخرى لاحقاً خذ نسخة احتياطية من «الإعدادات والنسخ» ثم استعدها.'
  $w.ForeColor = [System.Drawing.Color]::FromArgb(120, 80, 0)
  $w.SetBounds(20, 360, 620, 60)
  $f.Controls.Add($w)
  $c = New-Object System.Windows.Forms.Button
  $c.Text = 'إلغاء التثبيت'
  $c.SetBounds(20, 450, 160, 40)
  $c.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
  $f.Controls.Add($c)
  $f.CancelButton = $c
  $r = $f.ShowDialog()
  $f.Dispose()
  if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { return 'full' }
  if ($r -eq [System.Windows.Forms.DialogResult]::No) { return 'lite' }
  return 'cancel'
}


function Get-Resumable($url, $out) {
  $existing = 0
  if (Test-Path $out) { $existing = (Get-Item $out).Length }
  $req = [System.Net.HttpWebRequest]::Create($url)
  $req.UserAgent = 'JudicialAssistantSetup'
  $req.AllowAutoRedirect = $true
  $req.Timeout = 30000
  $req.ReadWriteTimeout = 30000
  if ($existing -gt 0) { $req.AddRange([int64]$existing) }
  $resp = $req.GetResponse()
  $status = [int]$resp.StatusCode
  $mode = [System.IO.FileMode]::Append
  if ($status -ne 206) { $mode = [System.IO.FileMode]::Create; $existing = 0 }
  $remaining = $resp.ContentLength
  $total = $existing + $remaining
  $inS = $resp.GetResponseStream()
  $fs = New-Object System.IO.FileStream($out, $mode, [System.IO.FileAccess]::Write)
  $buf = New-Object byte[] 65536
  $done = $existing
  $last = Get-Date
  try {
    while ($true) {
      $n = $inS.Read($buf, 0, $buf.Length)
      if ($n -le 0) { break }
      $fs.Write($buf, 0, $n)
      $done += $n
      if (((Get-Date) - $last).TotalSeconds -ge 2) {
        $last = Get-Date
        if ($total -gt 0) { $pct = [int](100 * $done / $total) } else { $pct = 0 }
        Write-Host ('   ' + [int]($done / 1MB) + ' MB of ' + [int]($total / 1MB) + ' MB  (' + $pct + '%)')
      }
    }
  } finally {
    $fs.Close(); $inS.Close(); $resp.Close()
  }
  if ($total -gt 0 -and $done -lt $total) { throw 'connection closed early' }
  return $true
}
function Download-Runtime($out) {
  if (Test-Path $out) {
    if ((Get-FileHash $out -Algorithm SHA256).Hash.ToLower() -eq $sha) { return $true }
  }
  $urls = @(
    "https://github.com/electron/electron/releases/download/v$ver/electron-v$ver-win32-x64.zip",
    "https://npmmirror.com/mirrors/electron/$ver/electron-v$ver-win32-x64.zip",
    "https://npmmirror.com/mirrors/electron/v$ver/electron-v$ver-win32-x64.zip",
    "https://cdn.npmmirror.com/binaries/electron/$ver/electron-v$ver-win32-x64.zip"
  )
  foreach ($u in $urls) {
    Write-Host ('Source: ' + $u)
    for ($try = 1; $try -le 5; $try++) {
      try {
        if (Get-Resumable $u $out) {
          $h = (Get-FileHash $out -Algorithm SHA256).Hash.ToLower()
          if ($h -eq $sha) { return $true }
          Write-Host '   checksum mismatch - discarding this download'
          Remove-Item $out -Force -ErrorAction SilentlyContinue
          break
        }
      } catch {
        Write-Host ('   interrupted (' + $_.Exception.Message + ') - retry ' + $try + ' of 5, resuming...')
        Start-Sleep -Seconds 3
        if ($_.Exception.Message -match '404|403') { break }
        if ($_.Exception.Message -match '416') { Remove-Item $out -Force -ErrorAction SilentlyContinue }
      }
    }
  }
  return $false
}

function Install-Full {
  $pkg = Join-Path $here 'JudicialAgendaApp'
  $localZip = Get-ChildItem -Path $here -Filter 'electron-v*-win32-x64.zip' -File -ErrorAction SilentlyContinue | Select-Object -First 1
  $appSrc = Join-Path $here 'app'
  Stop-App
  if (Test-Path (Join-Path $pkg 'JudicialAgenda.exe')) {
    Write-Host '1/3 Installing from the offline package (no internet needed)...'
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    Copy-Item $pkg $dest -Recurse
  }
  elseif (Test-Path $exe) {
    Write-Host '1/3 Existing full installation found - updating files (no internet needed)...'
  }
  elseif ($localZip) {
    Write-Host ('1/3 Using the local runtime file ' + $localZip.Name + ' (no internet needed)...')
    if ($localZip.Name -eq ("electron-v$ver-win32-x64.zip")) {
      $h = (Get-FileHash $localZip.FullName -Algorithm SHA256).Hash.ToLower()
      if ($h -ne $sha) { throw 'The local runtime file is corrupted (checksum mismatch).' }
    }
    Expand-Runtime $localZip.FullName
  }
  else {
    Write-Host '1/3 Downloading the runtime (about 110 MB, internet required)...'
    Write-Host '(Progress is shown below. If the connection drops, the download resumes automatically.)'
    if (-not (Download-Runtime $tmpZip)) { throw 'Could not download the runtime from any source. Check the internet connection and run Install.bat again - the partial download is kept and will resume. Or use the offline package: see README.' }
    Expand-Runtime $tmpZip
    Remove-Item $tmpZip -ErrorAction SilentlyContinue
  }
  Write-Host '2/3 Copying the application files...'
  if (Test-Path $appSrc) {
    $appDst = Join-Path $dest 'resources\app'
    if (Test-Path $appDst) { Remove-Item $appDst -Recurse -Force }
    Copy-Item $appSrc $appDst -Recurse
  }
  $setupDst = Join-Path $dest 'setup'
  Copy-SetupFiles $setupDst
  try { & (Join-Path $here 'Get-OCR-Engine.ps1') -Target (Join-Path $dest 'resources\app\ocr') } catch { Write-Host 'OCR engine download skipped (run Get-OCR-Engine.bat later with internet).' }
  Write-Host '3/3 Creating shortcuts and registering the uninstaller...'
  $icon = Join-Path $dest 'resources\app\icon.ico'
  $r = Register-Shortcuts $exe $null $dest $icon $setupDst
  $mk = Join-Path $setupDst 'make-offline-package.ps1'
  $prog = [Environment]::GetFolderPath('Programs')
  New-Lnk (Join-Path $prog ($appName + ' - إنشاء حزمة تثبيت أوفلاين.lnk')) $r[0] ('-NoProfile -ExecutionPolicy Bypass -File "' + $mk + '"') $null $icon 'make offline package'
  Register-Uninstaller $dest $icon (Read-Version (Join-Path $dest 'resources\app')) $r[0] $r[1]
  Start-Process $exe
}

function Install-Lite {
  Write-Host '1/3 Quick offline install (uses Microsoft Edge / Chrome already on this computer)...'
  $appSrc = Join-Path $here 'app'
  if (-not (Test-Path (Join-Path $appSrc 'index.html'))) { throw 'app\index.html was not found next to Install.bat - extract the whole zip first.' }
  if (-not (Test-Path $lite)) { New-Item -ItemType Directory -Path $lite | Out-Null }
  Write-Host '2/3 Copying the application files...'
  Copy-Item (Join-Path $appSrc 'index.html') (Join-Path $lite 'index.html') -Force
  foreach ($f in @('icon.ico', 'icon.png', 'package.json')) {
    $p = Join-Path $appSrc $f
    if (Test-Path $p) { Copy-Item $p (Join-Path $lite $f) -Force }
  }
  $setupDst = Join-Path $lite 'setup'
  Copy-SetupFiles $setupDst
  Write-Host '3/3 Creating shortcuts and registering the uninstaller...'
  $indexPath = Join-Path $lite 'index.html'
  $icon = Join-Path $lite 'icon.ico'
  $browser = Find-Browser
  if ($browser) {
    $uri = ([System.Uri]$indexPath).AbsoluteUri
    $bArgs = '--app="' + $uri + '" --user-data-dir="' + $liteData + '" --no-first-run --no-default-browser-check'
    $r = Register-Shortcuts $browser $bArgs $lite $icon $setupDst
    Register-Uninstaller $lite $icon (Read-Version $lite) $r[0] $r[1]
    Start-Process -FilePath $browser -ArgumentList $bArgs
  } else {
    $r = Register-Shortcuts $indexPath $null $lite $icon $setupDst
    Register-Uninstaller $lite $icon (Read-Version $lite) $r[0] $r[1]
    Start-Process $indexPath
  }
}

try {
  Write-Host ''
  Write-Host '=== Installing the application ===' -ForegroundColor Cyan
  $pkg0 = Join-Path $here 'JudicialAgendaApp'
  $hasZip = [bool](Get-ChildItem -Path $here -Filter 'electron-v*-win32-x64.zip' -File -ErrorAction SilentlyContinue | Select-Object -First 1)
  $hasRuntime = (Test-Path (Join-Path $pkg0 'JudicialAgenda.exe')) -or (Test-Path $exe) -or $hasZip
  $mode = ''
  while ($true) {
    $mode = Choose-Mode $hasRuntime
    if ($mode -ne 'full') { break }
    if ($hasRuntime -or (Test-Net)) { break }
    Say ('لا يوجد اتصال بالإنترنت حالياً، والنسخة الكاملة تحتاجه مرة واحدة لتنزيل المحرك.' + "`n`n" + 'اتصل بالإنترنت ثم اختر مرة أخرى، أو اختر «تثبيت بدون إنترنت».') 'Warning'
  }
  if ($mode -eq 'cancel') {
    Write-Host 'Installation cancelled.'
    Say 'تم إلغاء التثبيت ولم يتم تغيير أي شيء على جهازك.' 'Information'
    exit
  }
  if ($mode -eq 'full') { Install-Full } else { Install-Lite }
  Write-Host ''
  Write-Host 'DONE. Use the shortcut on your Desktop.' -ForegroundColor Green
  $msg = 'تم تثبيت ' + $appName + ' بنجاح.' + "`n`n" + 'ستجد اختصاراً على سطح المكتب وفي قائمة ابدأ. بعد التثبيت يعمل البرنامج بدون إنترنت.' + "`n" + 'لحذف البرنامج: إعدادات Windows ← التطبيقات، أو قائمة ابدأ ← «إلغاء تثبيت ' + $appName + '».'
  Say $msg 'Information'
} catch {
  Write-Host ''
  Write-Host ('FAILED: ' + $_.Exception.Message) -ForegroundColor Red
  Say ('تعذر التثبيت: ' + $_.Exception.Message) 'Error'
}
